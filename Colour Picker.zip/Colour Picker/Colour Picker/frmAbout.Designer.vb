﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAbout
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picColorPickerIcon = New System.Windows.Forms.PictureBox()
        Me.lblAppData = New System.Windows.Forms.Label()
        Me.lblAppDescription = New System.Windows.Forms.Label()
        Me.lblAppCopyright = New System.Windows.Forms.Label()
        CType(Me.picColorPickerIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picColorPickerIcon
        '
        Me.picColorPickerIcon.Location = New System.Drawing.Point(12, 12)
        Me.picColorPickerIcon.Name = "picColorPickerIcon"
        Me.picColorPickerIcon.Size = New System.Drawing.Size(127, 129)
        Me.picColorPickerIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picColorPickerIcon.TabIndex = 0
        Me.picColorPickerIcon.TabStop = False
        '
        'lblAppData
        '
        Me.lblAppData.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAppData.ForeColor = System.Drawing.Color.Teal
        Me.lblAppData.Location = New System.Drawing.Point(145, 12)
        Me.lblAppData.Name = "lblAppData"
        Me.lblAppData.Size = New System.Drawing.Size(200, 129)
        Me.lblAppData.TabIndex = 1
        Me.lblAppData.Text = "App Data"
        Me.lblAppData.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAppDescription
        '
        Me.lblAppDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAppDescription.Location = New System.Drawing.Point(12, 156)
        Me.lblAppDescription.Name = "lblAppDescription"
        Me.lblAppDescription.Size = New System.Drawing.Size(333, 109)
        Me.lblAppDescription.TabIndex = 2
        Me.lblAppDescription.Text = "App Description"
        '
        'lblAppCopyright
        '
        Me.lblAppCopyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAppCopyright.Location = New System.Drawing.Point(12, 265)
        Me.lblAppCopyright.Name = "lblAppCopyright"
        Me.lblAppCopyright.Size = New System.Drawing.Size(333, 31)
        Me.lblAppCopyright.TabIndex = 3
        Me.lblAppCopyright.Text = "App Copyright"
        Me.lblAppCopyright.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmAbout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(357, 305)
        Me.Controls.Add(Me.lblAppCopyright)
        Me.Controls.Add(Me.lblAppDescription)
        Me.Controls.Add(Me.lblAppData)
        Me.Controls.Add(Me.picColorPickerIcon)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAbout"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "About Color Picker"
        Me.TopMost = True
        CType(Me.picColorPickerIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picColorPickerIcon As PictureBox
    Friend WithEvents lblAppData As Label
    Friend WithEvents lblAppDescription As Label
    Friend WithEvents lblAppCopyright As Label
End Class
