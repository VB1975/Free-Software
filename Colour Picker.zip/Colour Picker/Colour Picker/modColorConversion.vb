﻿
Module modColorConversion

    Public H As Byte
    Public S As Byte
    Public V As Byte

    Public Sub RGBtoHSV(ByVal R As Byte, ByVal G As Byte, ByVal B As Byte,
                    ByRef H As Byte, ByRef S As Byte, ByRef V As Byte)

        Dim MinVal As Byte
        Dim MaxVal As Byte
        Dim Chroma As Byte
        Dim TempH As Single

        If R > G Then MaxVal = R Else MaxVal = G
        If B > MaxVal Then MaxVal = B
        If R < G Then MinVal = R Else MinVal = G
        If B < MinVal Then MinVal = B
        Chroma = MaxVal - MinVal

        V = MaxVal
        If MaxVal = 0 Then S = 0 Else S = Chroma / MaxVal * 255

        If Chroma = 0 Then
            H = 0
        Else
            Select Case MaxVal
                Case R
                    TempH = (1& * G - B) / Chroma
                    If TempH < 0 Then TempH = TempH + 6
                    H = TempH / 6 * 255
                Case G
                    H = (((1& * B - R) / Chroma) + 2) / 6 * 255
                Case B
                    H = (((1& * R - G) / Chroma) + 4) / 6 * 255
            End Select
        End If

    End Sub

    Public Sub HSVtoRGB(ByVal H As Byte, ByVal S As Byte, ByVal V As Byte,
                        ByRef R As Byte, ByRef G As Byte, ByRef B As Byte)

        Dim MinVal As Byte
        Dim MaxVal As Byte
        Dim Chroma As Byte
        Dim TempH As Single

        If V = 0 Then
            R = 0
            G = 0
            B = 0
        Else
            If S = 0 Then
                R = V
                G = V
                B = V
            Else
                MaxVal = V
                Chroma = S / 255 * MaxVal
                MinVal = MaxVal - Chroma
                Select Case H
                    Case Is >= 170
                        TempH = (H - 170) / 43
                        If TempH < 1 Then
                            B = MaxVal
                            R = MaxVal * TempH
                        Else
                            R = MaxVal
                            B = MaxVal * (2 - TempH)
                        End If
                        G = 0
                    Case Is >= 85
                        TempH = (H - 85) / 43
                        If TempH < 1 Then
                            G = MaxVal
                            B = MaxVal * TempH
                        Else
                            B = MaxVal
                            G = MaxVal * (2 - TempH)
                        End If
                        R = 0
                    Case Else
                        TempH = H / 43
                        If TempH < 1 Then
                            R = MaxVal
                            G = MaxVal * TempH
                        Else
                            G = MaxVal
                            R = MaxVal * (2 - TempH)
                        End If
                        B = 0
                End Select
                R = R / MaxVal * (MaxVal - MinVal) + MinVal
                G = G / MaxVal * (MaxVal - MinVal) + MinVal
                B = B / MaxVal * (MaxVal - MinVal) + MinVal
            End If
        End If

    End Sub
End Module
