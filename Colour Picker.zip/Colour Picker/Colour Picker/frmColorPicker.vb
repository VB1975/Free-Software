﻿Option Explicit On

Public Class frmColorPicker

    Private Sub SetRGB()

        Try

            Dim C As Color = picRGB.BackColor
            Dim R As Double = C.R / 255
            Dim G As Double = C.G / 255
            Dim B As Double = C.B / 255

            ' RGB from picturebox
            picRGB.BackColor = Color.FromArgb(CInt(txtRGBRed.Text), CInt(txtRGBGreen.Text), CInt(txtRGBBlue.Text))
            ' hexadecimal value
            txtHexadecimal.Text = ColorTranslator.ToHtml(C.FromArgb(C.ToArgb()))

            ' HSL ---------------------------------------------------------------------------------------------------
            txtHSLHue.Text = Math.Round(picRGB.BackColor.GetHue, 0)
            txtHSLSaturation.Text = Math.Round(picRGB.BackColor.GetSaturation * 100, 1)
            txtHSLLightness.Text = Math.Round(picRGB.BackColor.GetBrightness * 100, 1)

            txtHSLHue.Text = txtHSLHue.Text & Chr(176)
            txtHSLSaturation.Text = txtHSLSaturation.Text & Chr(37)
            txtHSLLightness.Text = txtHSLLightness.Text & Chr(37)

            ' HSV ---------------------------------------------------------------------------------------------------
            ' NOT WORKING TOTALLY RIGHT -  VALUES NEED VERIFYING (80% WORKING)
            RGBtoHSV(txtRGBRed.Text, txtRGBBlue.Text, txtRGBGreen.Text, H, S, V)

            txtHSVHue.Text = Math.Round(H, 0)
            txtHSVSatuation.Text = Math.Round(S, 0)
            txtHSVValue.Text = Math.Round(V, 0)

            txtHSVHue.Text = txtHSVHue.Text & Chr(176)
            txtHSVSatuation.Text = txtHSVSatuation.Text & Chr(37)
            txtHSVValue.Text = txtHSVValue.Text & Chr(37)

            ' CMYK --------------------------------------------------------------------------------------------------
            ' NOT WORKING - ONLY RETURNS A 1 OR A 0
            ' NEEDS TO RETURN ACTUAL PERCENTAGES
            txtCMYKKey.Text = Math.Round(1 - Math.Max(R, Math.Max(G, B)), 0)
            txtCMYKCyan.Text = Math.Round((1 - R - Val(txtCMYKKey.Text) / (1 - Val(txtCMYKKey.Text))), 0)
            txtCMYKMagenta.Text = Math.Round((1 - G - Val(txtCMYKKey.Text) / (1 - Val(txtCMYKKey.Text))), 0)
            txtCMYKYellow.Text = Math.Round((1 - B - Val(txtCMYKKey.Text) / (1 - Val(txtCMYKKey.Text))), 0)

            txtCMYKKey.Text = txtCMYKKey.Text & Chr(37)
            txtCMYKCyan.Text = txtCMYKCyan.Text & Chr(37)
            txtCMYKMagenta.Text = txtCMYKMagenta.Text & Chr(37)
            txtCMYKYellow.Text = txtCMYKYellow.Text & Chr(37)

        Catch ex As Exception

        End Try

    End Sub

    Private Sub scrRGBRed_Scroll(sender As Object, e As ScrollEventArgs) Handles scrRGBRed.Scroll

        txtRGBRed.Text = scrRGBRed.Value
        FormatRGB()

    End Sub

    Private Sub scrRGBGreen_Scroll(sender As Object, e As ScrollEventArgs) Handles scrRGBGreen.Scroll

        txtRGBGreen.Text = scrRGBGreen.Value
        FormatRGB()

    End Sub

    Private Sub scrRGBBlue_Scroll(sender As Object, e As ScrollEventArgs) Handles scrRGBBlue.Scroll

        txtRGBBlue.Text = scrRGBBlue.Value
        FormatRGB()

    End Sub

    Private Sub txtRGBRed_TextChanged(sender As Object, e As EventArgs) Handles txtRGBRed.TextChanged

        If txtRGBRed.Text = "" Then txtRGBRed.Text = "000"

        scrRGBRed.Value = txtRGBRed.Text
        SetRGB()

    End Sub

    Private Sub FormatRGB()

        If Len(txtRGBRed.Text) = 1 Then
            txtRGBRed.Text = "00" & txtRGBRed.Text
        ElseIf Len(txtRGBRed.Text) = 2 Then
            txtRGBRed.Text = "0" & txtRGBRed.Text
        End If

        If Len(txtRGBGreen.Text) = 1 Then
            txtRGBGreen.Text = "00" & txtRGBGreen.Text
        ElseIf Len(txtRGBGreen.Text) = 2 Then
            txtRGBGreen.Text = "0" & txtRGBGreen.Text
        End If

        If Len(txtRGBBlue.Text) = 1 Then
            txtRGBBlue.Text = "00" & txtRGBBlue.Text
        ElseIf Len(txtRGBBlue.Text) = 2 Then
            txtRGBBlue.Text = "0" & txtRGBBlue.Text
        End If

    End Sub

    Private Sub txtRGBGreen_TextChanged(sender As Object, e As EventArgs) Handles txtRGBGreen.TextChanged

        If txtRGBGreen.Text = "" Then txtRGBGreen.Text = "000"

        scrRGBGreen.Value = txtRGBGreen.Text
        SetRGB()

    End Sub

    Private Sub txtRGBBlue_TextChanged(sender As Object, e As EventArgs) Handles txtRGBBlue.TextChanged

        If txtRGBBlue.Text = "" Then txtRGBBlue.Text = "000"

        scrRGBBlue.Value = txtRGBBlue.Text
        SetRGB()

    End Sub

    Private Sub txtRGBRed_Leave(sender As Object, e As EventArgs) Handles txtRGBRed.Leave

        FormatRGB()

    End Sub

    Private Sub txtRGBGreen_Leave(sender As Object, e As EventArgs) Handles txtRGBGreen.Leave

        FormatRGB()

    End Sub

    Private Sub txtRGBBlue_Leave(sender As Object, e As EventArgs) Handles txtRGBBlue.Leave

        FormatRGB()

    End Sub

    Private Sub frmColorPicker_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FormatRGB()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()

    End Sub

    Private Sub btnGetColor_Click(sender As Object, e As EventArgs) Handles btnGetColor.Click

        CD1.Color = picRGB.BackColor
        CD1.ShowDialog()

        txtRGBRed.Text = CD1.Color.R
        txtRGBGreen.Text = CD1.Color.G
        txtRGBBlue.Text = CD1.Color.B

    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click

        Dim strAppData As String = ""
        Dim strAppDescription As String = ""
        Dim strAppCopyright As String = ""

        With frmAbout
            .Activate()

            .picColorPickerIcon.Image = My.Resources.Color_Wheel

            ' set app data
            strAppData = Application.ProductName & " " &
                Application.ProductVersion & vbNewLine & vbNewLine &
                Application.CompanyName

            ' set app description
            strAppDescription = My.Application.Info.Description

            ' set app copyright
            strAppCopyright = Chr(169) & " 2020 " & Application.CompanyName & ". All Rights Reserved!"

            .lblAppData.Text = strAppData
            .lblAppDescription.Text = strAppDescription
            .lblAppCopyright.Text = strAppCopyright

            .ShowDialog()

        End With

    End Sub
End Class
