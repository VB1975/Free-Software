﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmColorPicker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmColorPicker))
        Me.pnlRGB = New System.Windows.Forms.Panel()
        Me.picRGB = New System.Windows.Forms.PictureBox()
        Me.txtRGBBlue = New System.Windows.Forms.TextBox()
        Me.scrRGBBlue = New System.Windows.Forms.HScrollBar()
        Me.txtRGBGreen = New System.Windows.Forms.TextBox()
        Me.scrRGBGreen = New System.Windows.Forms.HScrollBar()
        Me.txtRGBRed = New System.Windows.Forms.TextBox()
        Me.scrRGBRed = New System.Windows.Forms.HScrollBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtHexadecimal = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.pnlHSL = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtHSLLightness = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtHSLSaturation = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHSLHue = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnGetColor = New System.Windows.Forms.Button()
        Me.CD1 = New System.Windows.Forms.ColorDialog()
        Me.pnlHSV = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtHSVValue = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtHSVSatuation = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtHSVHue = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.pnlCYMK = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtCMYKKey = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtCMYKMagenta = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtCMYKYellow = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtCMYKCyan = New System.Windows.Forms.TextBox()
        Me.mnuColorPicker = New System.Windows.Forms.MenuStrip()
        Me.mnuAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlRGB.SuspendLayout()
        CType(Me.picRGB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHSL.SuspendLayout()
        Me.pnlHSV.SuspendLayout()
        Me.pnlCYMK.SuspendLayout()
        Me.mnuColorPicker.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlRGB
        '
        Me.pnlRGB.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlRGB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlRGB.Controls.Add(Me.picRGB)
        Me.pnlRGB.Controls.Add(Me.txtRGBBlue)
        Me.pnlRGB.Controls.Add(Me.scrRGBBlue)
        Me.pnlRGB.Controls.Add(Me.txtRGBGreen)
        Me.pnlRGB.Controls.Add(Me.scrRGBGreen)
        Me.pnlRGB.Controls.Add(Me.txtRGBRed)
        Me.pnlRGB.Controls.Add(Me.scrRGBRed)
        Me.pnlRGB.Controls.Add(Me.Label3)
        Me.pnlRGB.Controls.Add(Me.Label2)
        Me.pnlRGB.Controls.Add(Me.Label1)
        Me.pnlRGB.Location = New System.Drawing.Point(12, 27)
        Me.pnlRGB.Name = "pnlRGB"
        Me.pnlRGB.Size = New System.Drawing.Size(476, 108)
        Me.pnlRGB.TabIndex = 0
        '
        'picRGB
        '
        Me.picRGB.BackColor = System.Drawing.Color.Black
        Me.picRGB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picRGB.Location = New System.Drawing.Point(374, 6)
        Me.picRGB.Name = "picRGB"
        Me.picRGB.Size = New System.Drawing.Size(89, 90)
        Me.picRGB.TabIndex = 12
        Me.picRGB.TabStop = False
        '
        'txtRGBBlue
        '
        Me.txtRGBBlue.Location = New System.Drawing.Point(307, 70)
        Me.txtRGBBlue.MaxLength = 3
        Me.txtRGBBlue.Name = "txtRGBBlue"
        Me.txtRGBBlue.Size = New System.Drawing.Size(61, 26)
        Me.txtRGBBlue.TabIndex = 2
        Me.txtRGBBlue.Text = "0"
        Me.txtRGBBlue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'scrRGBBlue
        '
        Me.scrRGBBlue.LargeChange = 5
        Me.scrRGBBlue.Location = New System.Drawing.Point(40, 76)
        Me.scrRGBBlue.Maximum = 259
        Me.scrRGBBlue.Name = "scrRGBBlue"
        Me.scrRGBBlue.Size = New System.Drawing.Size(264, 20)
        Me.scrRGBBlue.TabIndex = 10
        '
        'txtRGBGreen
        '
        Me.txtRGBGreen.Location = New System.Drawing.Point(307, 38)
        Me.txtRGBGreen.MaxLength = 3
        Me.txtRGBGreen.Name = "txtRGBGreen"
        Me.txtRGBGreen.Size = New System.Drawing.Size(61, 26)
        Me.txtRGBGreen.TabIndex = 1
        Me.txtRGBGreen.Text = "0"
        Me.txtRGBGreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'scrRGBGreen
        '
        Me.scrRGBGreen.LargeChange = 5
        Me.scrRGBGreen.Location = New System.Drawing.Point(40, 44)
        Me.scrRGBGreen.Maximum = 259
        Me.scrRGBGreen.Name = "scrRGBGreen"
        Me.scrRGBGreen.Size = New System.Drawing.Size(264, 20)
        Me.scrRGBGreen.TabIndex = 8
        '
        'txtRGBRed
        '
        Me.txtRGBRed.Location = New System.Drawing.Point(307, 6)
        Me.txtRGBRed.MaxLength = 3
        Me.txtRGBRed.Name = "txtRGBRed"
        Me.txtRGBRed.Size = New System.Drawing.Size(61, 26)
        Me.txtRGBRed.TabIndex = 0
        Me.txtRGBRed.Text = "0"
        Me.txtRGBRed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'scrRGBRed
        '
        Me.scrRGBRed.LargeChange = 5
        Me.scrRGBRed.Location = New System.Drawing.Point(40, 9)
        Me.scrRGBRed.Maximum = 259
        Me.scrRGBRed.Name = "scrRGBRed"
        Me.scrRGBRed.Size = New System.Drawing.Size(264, 20)
        Me.scrRGBRed.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.Location = New System.Drawing.Point(5, 76)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(21, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "B"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Green
        Me.Label2.Location = New System.Drawing.Point(5, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 20)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "G"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(5, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(22, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "R"
        '
        'txtHexadecimal
        '
        Me.txtHexadecimal.Location = New System.Drawing.Point(365, 177)
        Me.txtHexadecimal.MaxLength = 6
        Me.txtHexadecimal.Name = "txtHexadecimal"
        Me.txtHexadecimal.ReadOnly = True
        Me.txtHexadecimal.Size = New System.Drawing.Size(123, 26)
        Me.txtHexadecimal.TabIndex = 3
        Me.txtHexadecimal.TabStop = False
        Me.txtHexadecimal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(251, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 20)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Hexadecimal:"
        '
        'pnlHSL
        '
        Me.pnlHSL.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlHSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlHSL.Controls.Add(Me.Label7)
        Me.pnlHSL.Controls.Add(Me.txtHSLLightness)
        Me.pnlHSL.Controls.Add(Me.Label6)
        Me.pnlHSL.Controls.Add(Me.txtHSLSaturation)
        Me.pnlHSL.Controls.Add(Me.Label5)
        Me.pnlHSL.Controls.Add(Me.txtHSLHue)
        Me.pnlHSL.Location = New System.Drawing.Point(12, 167)
        Me.pnlHSL.Name = "pnlHSL"
        Me.pnlHSL.Size = New System.Drawing.Size(233, 115)
        Me.pnlHSL.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(5, 76)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 20)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Lightness:"
        '
        'txtHSLLightness
        '
        Me.txtHSLLightness.Location = New System.Drawing.Point(109, 73)
        Me.txtHSLLightness.MaxLength = 6
        Me.txtHSLLightness.Name = "txtHSLLightness"
        Me.txtHSLLightness.ReadOnly = True
        Me.txtHSLLightness.Size = New System.Drawing.Size(111, 26)
        Me.txtHSLLightness.TabIndex = 16
        Me.txtHSLLightness.TabStop = False
        Me.txtHSLLightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(5, 44)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 20)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Saturation:"
        '
        'txtHSLSaturation
        '
        Me.txtHSLSaturation.Location = New System.Drawing.Point(109, 41)
        Me.txtHSLSaturation.MaxLength = 6
        Me.txtHSLSaturation.Name = "txtHSLSaturation"
        Me.txtHSLSaturation.ReadOnly = True
        Me.txtHSLSaturation.Size = New System.Drawing.Size(111, 26)
        Me.txtHSLSaturation.TabIndex = 14
        Me.txtHSLSaturation.TabStop = False
        Me.txtHSLSaturation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(5, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 20)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Hue:"
        '
        'txtHSLHue
        '
        Me.txtHSLHue.Location = New System.Drawing.Point(109, 9)
        Me.txtHSLHue.MaxLength = 6
        Me.txtHSLHue.Name = "txtHSLHue"
        Me.txtHSLHue.ReadOnly = True
        Me.txtHSLHue.Size = New System.Drawing.Size(111, 26)
        Me.txtHSLHue.TabIndex = 12
        Me.txtHSLHue.TabStop = False
        Me.txtHSLHue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(255, 385)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(233, 38)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnGetColor
        '
        Me.btnGetColor.Location = New System.Drawing.Point(255, 141)
        Me.btnGetColor.Name = "btnGetColor"
        Me.btnGetColor.Size = New System.Drawing.Size(233, 27)
        Me.btnGetColor.TabIndex = 7
        Me.btnGetColor.Text = "Get Color"
        Me.btnGetColor.UseVisualStyleBackColor = True
        '
        'CD1
        '
        Me.CD1.AnyColor = True
        '
        'pnlHSV
        '
        Me.pnlHSV.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlHSV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlHSV.Controls.Add(Me.Label8)
        Me.pnlHSV.Controls.Add(Me.txtHSVValue)
        Me.pnlHSV.Controls.Add(Me.Label9)
        Me.pnlHSV.Controls.Add(Me.txtHSVSatuation)
        Me.pnlHSV.Controls.Add(Me.Label10)
        Me.pnlHSV.Controls.Add(Me.txtHSVHue)
        Me.pnlHSV.Location = New System.Drawing.Point(12, 308)
        Me.pnlHSV.Name = "pnlHSV"
        Me.pnlHSV.Size = New System.Drawing.Size(233, 115)
        Me.pnlHSV.TabIndex = 18
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(5, 76)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 20)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Value:"
        '
        'txtHSVValue
        '
        Me.txtHSVValue.Location = New System.Drawing.Point(109, 73)
        Me.txtHSVValue.MaxLength = 6
        Me.txtHSVValue.Name = "txtHSVValue"
        Me.txtHSVValue.ReadOnly = True
        Me.txtHSVValue.Size = New System.Drawing.Size(111, 26)
        Me.txtHSVValue.TabIndex = 16
        Me.txtHSVValue.TabStop = False
        Me.txtHSVValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(5, 44)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 20)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Saturation:"
        '
        'txtHSVSatuation
        '
        Me.txtHSVSatuation.Location = New System.Drawing.Point(109, 41)
        Me.txtHSVSatuation.MaxLength = 6
        Me.txtHSVSatuation.Name = "txtHSVSatuation"
        Me.txtHSVSatuation.ReadOnly = True
        Me.txtHSVSatuation.Size = New System.Drawing.Size(111, 26)
        Me.txtHSVSatuation.TabIndex = 14
        Me.txtHSVSatuation.TabStop = False
        Me.txtHSVSatuation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(5, 12)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(47, 20)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Hue:"
        '
        'txtHSVHue
        '
        Me.txtHSVHue.Location = New System.Drawing.Point(109, 9)
        Me.txtHSVHue.MaxLength = 6
        Me.txtHSVHue.Name = "txtHSVHue"
        Me.txtHSVHue.ReadOnly = True
        Me.txtHSVHue.Size = New System.Drawing.Size(111, 26)
        Me.txtHSVHue.TabIndex = 12
        Me.txtHSVHue.TabStop = False
        Me.txtHSVHue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(8, 144)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 20)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "HSL"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(8, 285)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 20)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "HSV"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(251, 212)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(58, 20)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "CMYK"
        '
        'pnlCYMK
        '
        Me.pnlCYMK.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlCYMK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlCYMK.Controls.Add(Me.Label17)
        Me.pnlCYMK.Controls.Add(Me.txtCMYKKey)
        Me.pnlCYMK.Controls.Add(Me.Label14)
        Me.pnlCYMK.Controls.Add(Me.txtCMYKMagenta)
        Me.pnlCYMK.Controls.Add(Me.Label15)
        Me.pnlCYMK.Controls.Add(Me.txtCMYKYellow)
        Me.pnlCYMK.Controls.Add(Me.Label16)
        Me.pnlCYMK.Controls.Add(Me.txtCMYKCyan)
        Me.pnlCYMK.Location = New System.Drawing.Point(255, 235)
        Me.pnlCYMK.Name = "pnlCYMK"
        Me.pnlCYMK.Size = New System.Drawing.Size(233, 141)
        Me.pnlCYMK.TabIndex = 21
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(5, 108)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(104, 20)
        Me.Label17.TabIndex = 19
        Me.Label17.Text = "Key (Black):"
        '
        'txtCMYKKey
        '
        Me.txtCMYKKey.Location = New System.Drawing.Point(109, 105)
        Me.txtCMYKKey.MaxLength = 6
        Me.txtCMYKKey.Name = "txtCMYKKey"
        Me.txtCMYKKey.ReadOnly = True
        Me.txtCMYKKey.Size = New System.Drawing.Size(111, 26)
        Me.txtCMYKKey.TabIndex = 18
        Me.txtCMYKKey.TabStop = False
        Me.txtCMYKKey.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Magenta
        Me.Label14.Location = New System.Drawing.Point(5, 43)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 20)
        Me.Label14.TabIndex = 17
        Me.Label14.Text = "Magenta:"
        '
        'txtCMYKMagenta
        '
        Me.txtCMYKMagenta.Location = New System.Drawing.Point(109, 40)
        Me.txtCMYKMagenta.MaxLength = 6
        Me.txtCMYKMagenta.Name = "txtCMYKMagenta"
        Me.txtCMYKMagenta.ReadOnly = True
        Me.txtCMYKMagenta.Size = New System.Drawing.Size(111, 26)
        Me.txtCMYKMagenta.TabIndex = 16
        Me.txtCMYKMagenta.TabStop = False
        Me.txtCMYKMagenta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Yellow
        Me.Label15.Location = New System.Drawing.Point(5, 75)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(66, 20)
        Me.Label15.TabIndex = 15
        Me.Label15.Text = "Yellow:"
        '
        'txtCMYKYellow
        '
        Me.txtCMYKYellow.Location = New System.Drawing.Point(109, 72)
        Me.txtCMYKYellow.MaxLength = 6
        Me.txtCMYKYellow.Name = "txtCMYKYellow"
        Me.txtCMYKYellow.ReadOnly = True
        Me.txtCMYKYellow.Size = New System.Drawing.Size(111, 26)
        Me.txtCMYKYellow.TabIndex = 14
        Me.txtCMYKYellow.TabStop = False
        Me.txtCMYKYellow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Cyan
        Me.Label16.Location = New System.Drawing.Point(5, 12)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 20)
        Me.Label16.TabIndex = 13
        Me.Label16.Text = "Cyan:"
        '
        'txtCMYKCyan
        '
        Me.txtCMYKCyan.Location = New System.Drawing.Point(109, 9)
        Me.txtCMYKCyan.MaxLength = 6
        Me.txtCMYKCyan.Name = "txtCMYKCyan"
        Me.txtCMYKCyan.ReadOnly = True
        Me.txtCMYKCyan.Size = New System.Drawing.Size(111, 26)
        Me.txtCMYKCyan.TabIndex = 12
        Me.txtCMYKCyan.TabStop = False
        Me.txtCMYKCyan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mnuColorPicker
        '
        Me.mnuColorPicker.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAbout})
        Me.mnuColorPicker.Location = New System.Drawing.Point(0, 0)
        Me.mnuColorPicker.Name = "mnuColorPicker"
        Me.mnuColorPicker.Size = New System.Drawing.Size(498, 24)
        Me.mnuColorPicker.TabIndex = 23
        Me.mnuColorPicker.Text = "MenuStrip1"
        '
        'mnuAbout
        '
        Me.mnuAbout.Name = "mnuAbout"
        Me.mnuAbout.Size = New System.Drawing.Size(61, 20)
        Me.mnuAbout.Text = "About..."
        '
        'frmColorPicker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(498, 435)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.pnlCYMK)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.pnlHSV)
        Me.Controls.Add(Me.btnGetColor)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.pnlHSL)
        Me.Controls.Add(Me.txtHexadecimal)
        Me.Controls.Add(Me.pnlRGB)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.mnuColorPicker)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuColorPicker
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.Name = "frmColorPicker"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Color Picker"
        Me.TopMost = True
        Me.pnlRGB.ResumeLayout(False)
        Me.pnlRGB.PerformLayout()
        CType(Me.picRGB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHSL.ResumeLayout(False)
        Me.pnlHSL.PerformLayout()
        Me.pnlHSV.ResumeLayout(False)
        Me.pnlHSV.PerformLayout()
        Me.pnlCYMK.ResumeLayout(False)
        Me.pnlCYMK.PerformLayout()
        Me.mnuColorPicker.ResumeLayout(False)
        Me.mnuColorPicker.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnlRGB As Panel
    Friend WithEvents txtRGBBlue As TextBox
    Friend WithEvents scrRGBBlue As HScrollBar
    Friend WithEvents txtRGBGreen As TextBox
    Friend WithEvents scrRGBGreen As HScrollBar
    Friend WithEvents txtRGBRed As TextBox
    Friend WithEvents scrRGBRed As HScrollBar
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents picRGB As PictureBox
    Friend WithEvents txtHexadecimal As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents pnlHSL As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents txtHSLLightness As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtHSLSaturation As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtHSLHue As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnGetColor As Button
    Friend WithEvents CD1 As ColorDialog
    Friend WithEvents pnlHSV As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents txtHSVValue As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtHSVSatuation As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtHSVHue As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents pnlCYMK As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents txtCMYKKey As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtCMYKMagenta As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtCMYKYellow As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtCMYKCyan As TextBox
    Friend WithEvents mnuColorPicker As MenuStrip
    Friend WithEvents mnuAbout As ToolStripMenuItem
End Class
