﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTimer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTimer))
        Me.pnlTimers = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblTimerCompHrs = New System.Windows.Forms.Label()
        Me.lblTimerCompMins = New System.Windows.Forms.Label()
        Me.lblTimerCompSecs = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblTimerComp10th = New System.Windows.Forms.Label()
        Me.lblTimerIndHrs = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTimerIndMins = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblTimerIndSecs = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblTimerInd10th = New System.Windows.Forms.Label()
        Me.timTimerInd = New System.Windows.Forms.Timer(Me.components)
        Me.btnStartStop = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnResetAll = New System.Windows.Forms.Button()
        Me.timTimerComp = New System.Windows.Forms.Timer(Me.components)
        Me.pnlTimers.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTimers
        '
        Me.pnlTimers.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.pnlTimers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlTimers.Controls.Add(Me.Label11)
        Me.pnlTimers.Controls.Add(Me.Label9)
        Me.pnlTimers.Controls.Add(Me.lblTimerCompHrs)
        Me.pnlTimers.Controls.Add(Me.lblTimerCompMins)
        Me.pnlTimers.Controls.Add(Me.lblTimerCompSecs)
        Me.pnlTimers.Controls.Add(Me.Label13)
        Me.pnlTimers.Controls.Add(Me.lblTimerComp10th)
        Me.pnlTimers.Controls.Add(Me.lblTimerIndHrs)
        Me.pnlTimers.Controls.Add(Me.Label5)
        Me.pnlTimers.Controls.Add(Me.lblTimerIndMins)
        Me.pnlTimers.Controls.Add(Me.Label3)
        Me.pnlTimers.Controls.Add(Me.lblTimerIndSecs)
        Me.pnlTimers.Controls.Add(Me.Label2)
        Me.pnlTimers.Controls.Add(Me.lblTimerInd10th)
        Me.pnlTimers.Location = New System.Drawing.Point(15, 16)
        Me.pnlTimers.Name = "pnlTimers"
        Me.pnlTimers.Size = New System.Drawing.Size(267, 100)
        Me.pnlTimers.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(120, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(24, 36)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = ":"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(56, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(24, 36)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = ":"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerCompHrs
        '
        Me.lblTimerCompHrs.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerCompHrs.ForeColor = System.Drawing.Color.Black
        Me.lblTimerCompHrs.Location = New System.Drawing.Point(8, 16)
        Me.lblTimerCompHrs.Name = "lblTimerCompHrs"
        Me.lblTimerCompHrs.Size = New System.Drawing.Size(61, 36)
        Me.lblTimerCompHrs.TabIndex = 15
        Me.lblTimerCompHrs.Text = "00"
        Me.lblTimerCompHrs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerCompMins
        '
        Me.lblTimerCompMins.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerCompMins.ForeColor = System.Drawing.Color.Black
        Me.lblTimerCompMins.Location = New System.Drawing.Point(73, 16)
        Me.lblTimerCompMins.Name = "lblTimerCompMins"
        Me.lblTimerCompMins.Size = New System.Drawing.Size(56, 36)
        Me.lblTimerCompMins.TabIndex = 13
        Me.lblTimerCompMins.Text = "00"
        Me.lblTimerCompMins.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerCompSecs
        '
        Me.lblTimerCompSecs.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerCompSecs.ForeColor = System.Drawing.Color.Black
        Me.lblTimerCompSecs.Location = New System.Drawing.Point(133, 16)
        Me.lblTimerCompSecs.Name = "lblTimerCompSecs"
        Me.lblTimerCompSecs.Size = New System.Drawing.Size(58, 36)
        Me.lblTimerCompSecs.TabIndex = 11
        Me.lblTimerCompSecs.Text = "00"
        Me.lblTimerCompSecs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(184, 16)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(23, 36)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = ":"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerComp10th
        '
        Me.lblTimerComp10th.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerComp10th.ForeColor = System.Drawing.Color.Black
        Me.lblTimerComp10th.Location = New System.Drawing.Point(195, 16)
        Me.lblTimerComp10th.Name = "lblTimerComp10th"
        Me.lblTimerComp10th.Size = New System.Drawing.Size(61, 36)
        Me.lblTimerComp10th.TabIndex = 9
        Me.lblTimerComp10th.Text = "00"
        Me.lblTimerComp10th.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerIndHrs
        '
        Me.lblTimerIndHrs.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerIndHrs.ForeColor = System.Drawing.Color.Teal
        Me.lblTimerIndHrs.Location = New System.Drawing.Point(43, 52)
        Me.lblTimerIndHrs.Name = "lblTimerIndHrs"
        Me.lblTimerIndHrs.Size = New System.Drawing.Size(40, 36)
        Me.lblTimerIndHrs.TabIndex = 8
        Me.lblTimerIndHrs.Text = "00"
        Me.lblTimerIndHrs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Teal
        Me.Label5.Location = New System.Drawing.Point(80, 52)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(14, 36)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = ":"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerIndMins
        '
        Me.lblTimerIndMins.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerIndMins.ForeColor = System.Drawing.Color.Teal
        Me.lblTimerIndMins.Location = New System.Drawing.Point(89, 52)
        Me.lblTimerIndMins.Name = "lblTimerIndMins"
        Me.lblTimerIndMins.Size = New System.Drawing.Size(40, 36)
        Me.lblTimerIndMins.TabIndex = 6
        Me.lblTimerIndMins.Text = "00"
        Me.lblTimerIndMins.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Teal
        Me.Label3.Location = New System.Drawing.Point(126, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 36)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = ":"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerIndSecs
        '
        Me.lblTimerIndSecs.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerIndSecs.ForeColor = System.Drawing.Color.Teal
        Me.lblTimerIndSecs.Location = New System.Drawing.Point(135, 52)
        Me.lblTimerIndSecs.Name = "lblTimerIndSecs"
        Me.lblTimerIndSecs.Size = New System.Drawing.Size(40, 36)
        Me.lblTimerIndSecs.TabIndex = 4
        Me.lblTimerIndSecs.Text = "00"
        Me.lblTimerIndSecs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Teal
        Me.Label2.Location = New System.Drawing.Point(172, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(14, 36)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = ":"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerInd10th
        '
        Me.lblTimerInd10th.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerInd10th.ForeColor = System.Drawing.Color.Teal
        Me.lblTimerInd10th.Location = New System.Drawing.Point(181, 52)
        Me.lblTimerInd10th.Name = "lblTimerInd10th"
        Me.lblTimerInd10th.Size = New System.Drawing.Size(40, 36)
        Me.lblTimerInd10th.TabIndex = 2
        Me.lblTimerInd10th.Text = "00"
        Me.lblTimerInd10th.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'timTimerInd
        '
        '
        'btnStartStop
        '
        Me.btnStartStop.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStartStop.ForeColor = System.Drawing.Color.Green
        Me.btnStartStop.Location = New System.Drawing.Point(31, 122)
        Me.btnStartStop.Name = "btnStartStop"
        Me.btnStartStop.Size = New System.Drawing.Size(241, 57)
        Me.btnStartStop.TabIndex = 2
        Me.btnStartStop.Text = "&Start"
        Me.btnStartStop.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.Teal
        Me.btnReset.Location = New System.Drawing.Point(31, 185)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(241, 57)
        Me.btnReset.TabIndex = 3
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnResetAll
        '
        Me.btnResetAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetAll.ForeColor = System.Drawing.Color.Blue
        Me.btnResetAll.Location = New System.Drawing.Point(31, 270)
        Me.btnResetAll.Name = "btnResetAll"
        Me.btnResetAll.Size = New System.Drawing.Size(241, 57)
        Me.btnResetAll.TabIndex = 4
        Me.btnResetAll.Text = "Reset &All"
        Me.btnResetAll.UseVisualStyleBackColor = True
        '
        'timTimerComp
        '
        '
        'frmTimer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(297, 342)
        Me.Controls.Add(Me.btnResetAll)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnStartStop)
        Me.Controls.Add(Me.pnlTimers)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.Name = "frmTimer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Timer"
        Me.TopMost = True
        Me.pnlTimers.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlTimers As Panel
    Friend WithEvents lblTimerInd10th As Label
    Friend WithEvents timTimerInd As Windows.Forms.Timer
    Friend WithEvents Label11 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblTimerCompHrs As Label
    Friend WithEvents lblTimerCompMins As Label
    Friend WithEvents lblTimerCompSecs As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblTimerComp10th As Label
    Friend WithEvents lblTimerIndHrs As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTimerIndMins As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblTimerIndSecs As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnStartStop As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnResetAll As Button
    Friend WithEvents timTimerComp As Windows.Forms.Timer
End Class
