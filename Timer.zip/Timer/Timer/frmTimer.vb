﻿Option Explicit On

Public Class frmTimer

    Private Sub IncreaseIndividualTimer()

        lblTimerInd10th.Text = Val(lblTimerInd10th.Text) + 1

        If lblTimerInd10th.Text >= 10 Then
            lblTimerInd10th.Text = 0
            lblTimerIndSecs.Text = Val(lblTimerIndSecs.Text) + 1
        End If

        If lblTimerIndSecs.Text >= 60 Then
            lblTimerIndSecs.Text = 0
            lblTimerIndMins.Text = Val(lblTimerIndMins.Text) + 1
        End If

        If lblTimerIndMins.Text >= 60 Then
            lblTimerIndMins.Text = 0
            lblTimerIndHrs.Text = Val(lblTimerIndHrs.Text) + 1
        End If

    End Sub

    Private Sub IncreaseCompoundedTimer()

        lblTimerComp10th.Text = Val(lblTimerComp10th.Text) + 1

        If lblTimerComp10th.Text >= 10 Then
            lblTimerComp10th.Text = 0
            lblTimerCompSecs.Text = Val(lblTimerCompSecs.Text) + 1
        End If

        If lblTimerCompSecs.Text >= 60 Then
            lblTimerCompSecs.Text = 0
            lblTimerCompMins.Text = Val(lblTimerCompMins.Text) + 1
        End If

        If lblTimerCompMins.Text >= 60 Then
            lblTimerCompMins.Text = 0
            lblTimerCompHrs.Text = Val(lblTimerCompHrs.Text) + 1
        End If

    End Sub

    Private Sub FormatTimers()

        Dim Ctrl As Control

        For Each Ctrl In pnlTimers.Controls
            If TypeOf Ctrl Is Label Then
                If Len(Ctrl.Text) = 1 Then
                    If Ctrl.Text <> ":" Then
                        Ctrl.Text = "0" & Ctrl.Text
                    End If
                End If
            End If
        Next

    End Sub
    Private Sub btnStartStop_Click(sender As Object, e As EventArgs) Handles btnStartStop.Click

        If timTimerComp.Enabled = False Then
            timTimerComp.Enabled = True
        End If

        If timTimerInd.Enabled Then
            timTimerInd.Enabled = False
            timTimerComp.Enabled = False
        Else
            timTimerInd.Enabled = True
            timTimerComp.Enabled = True
        End If

        StartIndividualTimer()

    End Sub

    Private Sub StartIndividualTimer()

        If timTimerInd.Enabled Then
            btnStartStop.Text = "&Stop"
            btnStartStop.ForeColor = Color.DarkRed
        Else
            btnStartStop.Text = "&Start"
            btnStartStop.ForeColor = Color.Green
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Dim Ctrl As Control

        timTimerInd.Enabled = False

        For Each Ctrl In pnlTimers.Controls
            If TypeOf Ctrl Is Label Then
                If Ctrl.Text <> ":" Then
                    If InStr(Ctrl.Name, "Ind") <> 0 Then
                        Ctrl.Text = "00"
                    End If
                End If
            End If
        Next

        StartIndividualTimer()

    End Sub

    Private Sub btnResetAll_Click(sender As Object, e As EventArgs) Handles btnResetAll.Click

        Dim Ctrl As Control

        timTimerInd.Enabled = False
        timTimerComp.Enabled = False

        For Each Ctrl In pnlTimers.Controls
                If TypeOf Ctrl Is Label Then
                    If Ctrl.Text <> ":" Then
                        Ctrl.Text = "00"
                    End If
                End If
            Next

        StartIndividualTimer()

    End Sub

    Private Sub timTimerInd_Tick(sender As Object, e As EventArgs) Handles timTimerInd.Tick

        IncreaseIndividualTimer()
        FormatTimers()

    End Sub

    Private Sub timTimerComp_Tick(sender As Object, e As EventArgs) Handles timTimerComp.Tick

        IncreaseCompoundedTimer()
        FormatTimers()

    End Sub
End Class
